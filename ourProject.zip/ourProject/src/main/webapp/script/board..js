function insert(url,name){
    if(`${id.id}`===""){
        return false;
    }else{
        window.open(url,name,"width=250, height=200");
    }
}
function view(url,name){
    window.open(url,name,"width=600, height=500");
}
function close(url){
    return window.close(url);
}