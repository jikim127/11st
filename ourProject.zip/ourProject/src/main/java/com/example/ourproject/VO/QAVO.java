package com.example.ourproject.VO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class QAVO {
    private int seq;
    private int no;
    private String id;
    private String pass;
    private String title;
    private String content;
}
