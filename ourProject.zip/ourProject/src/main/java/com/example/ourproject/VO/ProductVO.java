package com.example.ourproject.VO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProductVO {
    private int no;
    private String title;
    private int price;
    private String image;
}
